//
//  UserInformation.h
//  VTCSDKIOS
//
//  Created by AF on 5/26/16.
//  Copyright © 2016 AF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInformation : NSObject
{
    NSString *_accountID;
    NSString *_accountName;
    NSString *_accesstoken;
}
@property (nonatomic, strong) NSString *accountID;
@property (nonatomic, strong) NSString *accountName;
@property (nonatomic, strong) NSString *accesstoken;
@end
