//
//  InformationView.h
//  VTCSDKIOS
//
//  Created by Archduke Frog on 7/9/14.
//  Copyright (c) 2014 AF. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol InformationViewDelegate;

@protocol InformationViewDelegate <NSObject>

- (void) accountWasChangedithAccountID:(NSString *)accountId withAccountName:(NSString *)accountName withAccesstoken:(NSString *)accesstoken;

@end

typedef void(^InformationViewCompletionBlock)(BOOL cancelled, NSInteger buttonIndex);

@interface InformationView : UIViewController
@property (nonatomic, strong) id<InformationViewDelegate>delegate;
@property (nonatomic, getter = isVisible) BOOL visible;

/**************************Show view Information Account **********************************/
+ (void) showUserInfoWithDelegate:(id)delegate;

@end
