//
//  ListPaymentView.h
//  VTCSDKIOS
//
//  Created by Archduke Frog on 8/11/14.
//  Copyright (c) 2014 AF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>

@protocol ListPaymentViewDelegate;

@protocol ListPaymentViewDelegate <NSObject>

- (void) showLoadingWhenTopUpInAppPurchase;
- (void) hiddenLoadingWhenCancelOrTopUpInAppPurchaseCompleted;

@end

typedef void(^ListPaymentViewCompletionBlock)(BOOL cancelled, NSInteger buttonIndex);

UIKIT_EXTERN NSString *const IAPHelperProductPurchasedNotification;

typedef void (^RequestProductsCompletionHandler)(BOOL success, NSArray * products);

@interface ListPaymentView : UIViewController {
    void (^_completionTotalScoin)(NSString *totalScoin);
}

@property (nonatomic, getter = isVisible) BOOL visible;
@property (nonatomic, strong) id<ListPaymentViewDelegate>delegate;

+ (ListPaymentView *)shareInstance;

/**************************Show view payment with partnerInfo **********************************/
+ (void) makePaymentWithDelegate:(id)delegate withPartnerInfo:(NSString *)partnerInfo;

- (void) getUserBalanceWithCompletionTotalScoin:(void(^)(NSString *totalScoin))completionTotalScoin;

- (void) doScoinPaymentWithDelegate:(id)delegate withPartnerInfo:(NSString *)partnerInfo withAmount:(NSString *)amount;

@end
