//
//  VTCSDKIOS.h
//  VTCSDKIOS
//
//  Created by AF on 11/5/15.
//  Copyright (c) 2015 AF. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VTCSDKIOS.
FOUNDATION_EXPORT double VTCSDKIOSVersionNumber;

//! Project version string for VTCSDKIOS.
FOUNDATION_EXPORT const unsigned char VTCSDKIOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VTCSDKIOS/PublicHeader.h>


#import <VTCSDKIOS/HEXCMyUIButton.h>
#import <VTCSDKIOS/InformationView.h>
#import <VTCSDKIOS/ListPaymentView.h>
#import <VTCSDKIOS/InviteFacebookView.h>
#import <VTCSDKIOS/LoginScoinView.h>
#import <VTCSDKIOS/MBProgressHUD.h>
#import <VTCSDKIOS/UserInformation.h>
#import <VTCSDKIOS/PaymentInformation.h>