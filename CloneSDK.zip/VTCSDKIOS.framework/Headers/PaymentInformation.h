//
//  PaymentInformation.h
//  VTCSDKIOS
//
//  Created by AF on 5/26/16.
//  Copyright © 2016 AF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PaymentInformation : NSObject
{
    NSString *_amount;
    NSString *_time;
    NSString *_transactionid;
    NSString *_type;
}
@property (nonatomic, strong) NSString *amount;
@property (nonatomic, strong) NSString *time;
@property (nonatomic, strong) NSString *transactionid;
@property (nonatomic, strong) NSString *type;
@end
