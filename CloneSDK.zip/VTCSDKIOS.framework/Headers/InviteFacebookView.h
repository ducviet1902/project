//
//  InviteFacebookView.h
//  VTCSDKIOS
//
//  Created by Archduke Frog on 7/16/15.
//  Copyright (c) 2015 Nguyen Mau Dat. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol InviteFacebookViewDelegate;

@protocol InviteFacebookViewDelegate <NSObject>

- (void) inviteFriendsFacebookSuccessWithRequestID:(NSString *)requestIdFB withNumberPeople:(NSInteger)numberPeople;

@end
typedef void(^InviteFacebookViewCompletionBlock)(BOOL cancelled, NSInteger buttonIndex);

@interface InviteFacebookView : UIViewController
{
    void (^_completionHandler)(BOOL finished);
}

@property (nonatomic, strong) id<InviteFacebookViewDelegate>delegate;
@property (nonatomic, getter = isVisible) BOOL visible;

+ (InviteFacebookView *) sharedInstance;

+ (void) inviteFacebookWithDelegate:(id)delegate;

- (void) publishFacebookFeedWithTitle:(NSString *)title withDescription:(NSString *)description withLinkImage:(NSString *)linkImage withLinkShare:(NSString *)linkShare handler:(void (^)(BOOL finished))completionHandler;
@end
