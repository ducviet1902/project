//
//  LoginScoinView.h
//  VTCSDKIOS
//
//  Created by Archduke Frog on 7/28/14.
//  Copyright (c) 2014 AF. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^LoginScoinViewCompletionBlock)(BOOL cancelled, NSInteger buttonIndex);


@interface LoginScoinView : UIViewController {
    void (^_completionHandlerReminder)(NSString *reminder);
    void (^_completionHandlerGameRating)(NSString *gameRating);
    void (^_completionHandlerAvatar)(NSString *urlAvatar);
}

@property (nonatomic, getter = isVisible) BOOL visible;

+ (LoginScoinView *) sharedInstance;

// WithURLSandbox:YES using url Sandbox;
// WithURLSandbox:NO using url Live;
+ (void) setUpSDKWithAgencyID:(NSString *)agencyID withAPIKeyLive:(NSString *)apikeyLive withAPIKeySandbox:(NSString *)apikeySandbox withURLSandbox:(BOOL)yesOrNo;

/************************* Setting key Google ClientID ***********************/

+ (void) setUpKeyGoogleClientID:(NSString *)keyGoogleClientID;

/************************* Setting key Google Analytics ClientID ***********************/

+ (void) setDefaultGoogleAnalyticID:(NSString *)googleAnalyticID;

/************************* Auto login account Scoin id ***********************/

- (void) autoLoginScoin;

/**************************Show view login account Scoin id **********************************/

- (void) manualLoginScoin;

/************************** Logout account Scoin id **********************************/

- (void) logoutScoin;

/**************************Get game rating **********************************/

- (void) getGameRatingWithCompletionHandler:(void(^)(NSString *gameRating))completionHandler;

/**************************Get reminder **********************************/

- (void) getReminderWithCompletionHandler:(void(^)(NSString *reminder))completionHandler;

/**************************Get avatar **********************************/

- (void) getAvatarWithCompletionHandler:(void(^)(NSString *urlAvatar))completionHandler;

/**************************Set key appsflyer and appleAppID **********************************/

- (void) setAppsflyerDevKey:(NSString *)appsflyerDevKey andAppleAppID:(NSString *)appleAppID;

/************************** Track Installs, updates & sessions(app opens) (You must include this API to enable tracking)**********************************/

- (void) trackingInstallAppWihtAppsflyer;

- (void) trackingInstallAppWithGoogleAnanlytics:(NSURL *)urlContents;

/**************************Send device token to server**********************************/

- (void) sendDeviceTokenToServer:(NSString *)deviceToken;

/**************************Genarate userInfo from Apple service **********************************/

- (void) genarateUserInfo:(NSDictionary *)userInfo withApplication:(UIApplication *)application;


/**************************Facebook SDK Active App **********************************/

- (BOOL) application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

- (void) activateApp;

@end

#define CHECKLOGIN                      @"check login"
#define SHOWINFOMATIONUSER              @"show information"
#define LOGIN_SUCCESS_ACTION            @"name notify get user information"
#define KEY_LOGIN_SUCCESS_ACTION        @"key notify get user information"
#define PAYMENT_SUCCESS_ACTION          @"name notify get payment information"
#define KEY_PAYMENT_SUCCESS_ACTION      @"key notify get payment information"
#define LOGOUT_SUCCESS_ACTION           @"name notify the player has logged out"
#define KEY_LOGOUT_SUCCESS_ACTION           @"key notify the player has logged out"

#define IS_IPAD (( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ) ? YES : NO)
#define IS_IPHONE_5 (([UIScreen mainScreen].scale == 2.f && [UIScreen mainScreen].bounds.size.height == 568)?YES:NO)
#define IS_RETINA_DISPLAY_DEVICE (([UIScreen mainScreen].scale == 2.f)?YES:NO)
#define kiPhone (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height
